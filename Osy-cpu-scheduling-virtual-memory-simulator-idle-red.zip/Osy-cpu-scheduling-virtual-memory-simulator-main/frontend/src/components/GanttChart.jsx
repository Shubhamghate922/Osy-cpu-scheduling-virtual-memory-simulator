function isIdleSegment(segment) {
  return String(segment.id).toUpperCase() === "IDLE";
}

function getSegmentColor(segment, index) {
  if (isIdleSegment(segment)) {
    return "bg-red-500";
  }

  const colors = ["bg-purple-600", "bg-purple-400"];
  return colors[index % colors.length];
}

function GanttChart({ ganttChart }) {
  if (!ganttChart || ganttChart.length === 0) {
    return null;
  }

  const startTime = ganttChart[0].start;
  const endTime = ganttChart[ganttChart.length - 1].end;
  const totalTime = endTime - startTime;

  return (
    <div className="bg-white border border-purple-200 rounded-xl shadow-sm p-5">
      <h3 className="text-purple-700 font-bold text-xl mb-5">Gantt Chart</h3>

      <div className="overflow-x-auto pb-2">
        <div
          className="relative min-w-full"
          style={{ minWidth: `${Math.max(totalTime * 65, 500)}px` }}
        >
          {/* Process blocks */}
          <div className="flex w-full border border-gray-300 overflow-hidden rounded-sm">
            {ganttChart.map((segment, index) => {
              const duration = segment.end - segment.start;
              const width = (duration / totalTime) * 100;

              return (
                <div
                  key={`${segment.id}-${segment.start}-${index}`}
                  style={{ width: `${width}%` }}
                  className={`h-16 flex items-center justify-center text-white text-xl font-medium border-r border-white last:border-r-0 ${getSegmentColor(
                    segment,
                    index
                  )}`}
                >
                  {isIdleSegment(segment) ? "CPU Idle" : segment.id}
                </div>
              );
            })}
          </div>

          {/* Time scale */}
          <div className="relative h-9 w-full">
            <span className="absolute left-0 top-1 -translate-x-1/2 text-gray-700 text-sm">
              {startTime}
            </span>

            {ganttChart.map((segment, index) => {
              if (index === ganttChart.length - 1) {
                return null;
              }

              const position = ((segment.end - startTime) / totalTime) * 100;

              return (
                <span
                  key={`time-${index}`}
                  style={{ left: `${position}%` }}
                  className="absolute top-1 -translate-x-1/2 text-gray-700 text-sm"
                >
                  {segment.end}
                </span>
              );
            })}

            <span className="absolute right-0 top-1 translate-x-1/2 text-gray-700 text-sm">
              {endTime}
            </span>
          </div>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-gray-600">
        <div className="flex items-center gap-2">
          <span className="h-4 w-4 rounded-sm bg-red-500"></span>
          <span>CPU Idle</span>
        </div>
        <div>Total time elapsed: {endTime}</div>
      </div>
    </div>
  );
}

export default GanttChart;
